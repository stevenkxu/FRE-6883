#include <string>
#include <iostream>
#include <fstream>
#include "ExtractData.h"
#include <vector>
#include "tools.h"
#include "EquityDivide.h"
using namespace std;

int main()
{
    // delete previous file
    ifstream fin;
    ofstream fout;
    
    vector<string> Tradedate;
    fin.open("tradedate.txt");
    string tem;
    while(fin>>tem)
    {
        Tradedate.push_back(tem);
    }
    fin.close();
    
    remove("Results.csv");
    vector<string> Tickers;
    vector<string> AnnounceDate;
    
    // download stock information including benchmark
    Tickers.push_back("^GSPC");

    string tickers, date;
    double est, act, sur;
    fin.open("EPS/EPS.csv");
    
    int testi = 0;
    while (fin >> tickers >> date >> act >> est >> sur)
    {
        Tickers.push_back(tickers);
        AnnounceDate.push_back(date);
        testi++;
        if(testi == 3)
            break;
    }
    fin.close();
    
    cout << Tickers.size() << endl;
    

    Extract(Tickers);
    
    
    int i = 0;
    string Date, Open, High, Low, Close, AdjClose, Volume;
    vector<string> Temp1;
    vector<double> Temp2;
    
    fin.open("Results.csv");
    while (getline(fin, Date, ','), getline(fin, Open, ','), getline(fin, High, ','), getline(fin, Low, ','), getline(fin, Close, ','), getline(fin, AdjClose, ','), getline(fin, Volume, ','))
    {
        if (Date == "Date")
        {
            fout.close();
            Temp1.clear();
            Temp2.clear();
            fout.open(Tickers[i] + ".bat");//storage single stock data into .bat file
            i++;
        }
    }
    fin.close();
    
    
    /*
    string path = "EPS/EPS.csv";
    EquityDivide test1(path);
    Group group1 = test1.divide_group();
    */
    /*
    vector<TickerInfo>::iterator iter;
    for(iter = group1.at(0).begin(); iter <= group1.at(0).end(); iter++)
        cout << iter->first << " "<< iter-> second << endl;
    */
    
    
    
}
