#include <string>
#include <iostream>
#include "ExtractData.h"
#include <vector>

using namespace std;

int main()
{
    // delete previous file
    remove("Results.csv");
    vector<string> Tickers;
    
    Tickers.push_back("^GSPC");
    Tickers.push_back("AAPL");
    
    // download stock information including benchmark
    Extract(Tickers);
    
}
