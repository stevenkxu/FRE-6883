#ifndef Selectdata_h
#define Selectdata_h

#include <string>
#include <iostream>
#include <fstream>
#include "ExtractData.h"
#include <vector>
#include "tools.h"
#include "Stock.h"
#include "EquityDivide.h"
#include <map>

using namespace std;

typedef map<string,vector<string>> Map;

// number = 0 means miss, 1 is meet, 2is
void SelectData(StockMap &StockList)
{
    ifstream fin;
    ofstream fout;
    
    remove("Results.csv");
    cout << "++++++" << endl;
    Extract(StockList, "2019-01-10", "2019-08-20");
    cout << "++++++" << endl;
    
    string Date, Open, High, Low, Close, Volume;
    fin.open("Results.csv");
    string AdjClose;
    
    
    /*
    int i = 0;
    int countindex = 0;
    int length = 155;
    while (getline(fin, Date, ','), getline(fin, Open, ','), getline(fin, High, ','), getline(fin, Low, ','), getline(fin, Close, ','), getline(fin, AdjClose, ','), getline(fin, Volume))
    {
        countindex++;
        if (countindex == (PreStartIndex[i] + i*length))
        {
            vector<string> temvector;
            AdjClose = "";
            for(int j = 0; j < 61; j++)
            {
                countindex++;
                getline(fin, Date, ','), getline(fin, Open, ','), getline(fin, High, ','), getline(fin, Low, ','), getline(fin, Close, ','), getline(fin, AdjClose, ','), getline(fin, Volume);
                temvector.push_back(AdjClose);
                cout <<AdjClose;
            }
            StockList[Tickers[i]].AdjClose = temvector;
            Price.insert(make_pair(Tickers[i],temvector));
            i++;
            
        }
     }
     */
    
    cout << "++++++" << endl;
    auto itr = StockList.begin();
    vector<string> temvector;
    cout << "++++++" << endl;
    
    getline(fin, Date, ','), getline(fin, Open, ','), getline(fin, High, ','), getline(fin, Low, ','), getline(fin, Close, ','), getline(fin, AdjClose, ','), getline(fin, Volume);
    
    while (getline(fin, Date, ','), getline(fin, Open, ','), getline(fin, High, ','), getline(fin, Low, ','), getline(fin, Close, ','), getline(fin, AdjClose, ','), getline(fin, Volume))
    {
        cout << "rrrrr"<<AdjClose << endl;
        temvector.push_back(AdjClose);
        if (Date == "Date")
        {
            cout << "DDDDDD"<<Date<<endl;
            temvector.pop_back();
            itr->second.AdjClose = temvector;
            temvector.clear();
            itr++;
        }
        
        
        if(itr == StockList.end())
            break;
    }
    fin.close();




    fin.close();
    
    /*
    for(Map::const_iterator it = Price.begin(); it != Price.end(); ++it)
    {
        cout << it->first << endl;
        for(auto iter = it->second.begin(); iter != it->second.end() ; ++iter)
        {
            cout << *iter << " ";
        }
        cout << endl;
    }
     */
    
}


vector<string> getSPY()
{
    ifstream fin;
    ofstream fout;
    vector<string> Tickers;
    Tickers.push_back("^GSPC");
    remove("Results.csv");
    
    Extract(Tickers, "2019-01-10", "2019-08-20");
    
    string Date, Open, High, Low, Close, Volume;
    fin.open("Results.csv");
    string AdjClose;
    vector<string> tempvecotr;

    while (getline(fin, Date, ','), getline(fin, Open, ','), getline(fin, High, ','), getline(fin, Low, ','), getline(fin, Close, ','), getline(fin, AdjClose, ','), getline(fin, Volume))
    {
        if(AdjClose != "Adj Close")
            tempvecotr.push_back(AdjClose);
    }
    return tempvecotr;
}


#endif /* Selectdata_h */
